#!/bin/bash
# Quick SSH into Mac Mini

MACMINI_USER="macmini"
MACMINI_IP="192.168.1.50"

ssh $MACMINI_USER@$MACMINI_IP
