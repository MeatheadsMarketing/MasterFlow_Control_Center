import streamlit as st
import subprocess

st.set_page_config(page_title="iPad Trigger Companion", layout="centered")
st.title("📲 Remote Assistant Control")

if st.button("Run Vault Sweep"):
    st.write("[+] Triggering Vault Sweeper...")
    subprocess.Popen(["python3", "../macmini/vault_sweeper_agent.py"])

if st.button("Sync Notion"):
    st.write("[+] Syncing with Notion...")
    subprocess.Popen(["python3", "../imac/notion_sync_neuroframe.py"])

if st.button("Launch Streamlit UI"):
    st.write("[+] Launching Streamlit UI...")
    subprocess.Popen(["python3", "../imac/streamlit_launcher.py"])
