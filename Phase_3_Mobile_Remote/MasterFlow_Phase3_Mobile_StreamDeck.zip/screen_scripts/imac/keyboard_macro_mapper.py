import os

macros = {
    "F1": "Run Vault Sweep",
    "F2": "Sync to Notion",
    "F3": "Launch Streamlit",
    "F4": "Trigger Mac Mini"
}

print("Mapping Stream Deck Macros:")
for key, action in macros.items():
    print(f"{key} => {action}")
# NOTE: Actual key mapping is handled via Stream Deck software or command layer integration
