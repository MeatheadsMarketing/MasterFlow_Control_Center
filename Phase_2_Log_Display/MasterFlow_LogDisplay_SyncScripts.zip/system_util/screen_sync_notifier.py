import datetime

now = datetime.datetime.now()
log = f"[+] Sync Check-In @ {now.strftime('%Y-%m-%d %H:%M:%S')}\nStatus: OK\n"

with open("sync_log.md", "a") as f:
    f.write(log)

print("[✓] System Sync Log Updated.")
