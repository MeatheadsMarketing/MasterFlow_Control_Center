import json
import time

status_data = {
    "Notion Sync": "Success",
    "GitHub Push": "Pending",
    "Assistant Run": "Live: Assistant_Builder_v2",
    "Vault Space": "72% Free",
    "Last Sweep": "4 hours ago"
}

print("[+] Assistant Status Dashboard")
for k, v in status_data.items():
    print(f"{k}: {v}")
    time.sleep(0.5)
