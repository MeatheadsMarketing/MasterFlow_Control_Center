import os

required_files = [
    "stream_scripts/imac/run_all_stack_protocols.sh",
    "stream_scripts/imac/streamlit_launcher.py",
    "screen_scripts/macmini/vault_sweeper_agent.py",
    "screen_scripts/monitor/log_scroller_display.py",
    "screen_scripts/ipad/remote_trigger_companion.py"
]

print("[+] Validating screen system structure...")
for file in required_files:
    if os.path.exists(file):
        print(f"✓ {file}")
    else:
        print(f"✗ MISSING: {file}")
