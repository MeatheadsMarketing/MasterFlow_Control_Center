# Master Flow Command Center – System Utility Suite

This folder contains utilities to validate and orchestrate your full assistant stack:

- `screen_validation_check.py`: Validates file presence per screen
- `screen_registry.json`: Maps screen roles and assigned scripts
- `.env`: Stores system-wide variables and secrets
