import os
import subprocess

# Replace with your Mac mini IP or hostname
macmini_ip = "192.168.1.50"
remote_command = "python3 /Users/macmini/skywall/launch_remote_stack.py"

print("[+] Triggering Mac mini...")
subprocess.run(["ssh", f"macmini@{macmini_ip}", remote_command])
