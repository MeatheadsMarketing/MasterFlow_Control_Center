import os
import subprocess

print("[+] Launching Streamlit Assistant Dashboard...")
subprocess.run(["streamlit", "run", "main_app.py"])
