#!/bin/bash
# Master Protocol Script: Builds, Audits, Syncs, and Launches Dashboard

echo "[+] Starting Full Stack Protocol..."

python3 streamlit_launcher.py &
python3 notion_sync_neuroframe.py &
bash trigger_macmini.py &

wait
echo "[✓] All Core Protocols Executed Successfully."
