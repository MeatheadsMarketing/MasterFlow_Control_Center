import streamlit as st
import subprocess
import os

st.set_page_config(page_title="MasterFlow Launcher", layout="wide")
st.title("🚀 MasterFlow Assistant Launcher")

# Sidebar toggle for Simulator Mode
mode = st.sidebar.radio("Select Mode", ["Live Mode", "Simulator Mode"])

if mode == "Live Mode":
    st.success("Live Mode Selected")
    if st.button("Launch Live Assistant Stack"):
        st.write("[+] Launching Streamlit Dashboard...")
        subprocess.Popen(["streamlit", "run", "main_app.py"])
        st.write("[✓] Live dashboard launched.")
    if st.button("Run Full Protocol Stack"):
        st.write("[+] Executing Full System Stack...")
        os.system("bash run_all_stack_protocols.sh")
        st.write("[✓] Full protocol completed.")
else:
    st.warning("Simulator Mode Selected")
    if st.button("Run Display Simulator"):
        st.write("[+] Launching Display Simulator...")
        subprocess.Popen(["streamlit", "run", "simulators/display_simulator.py"])
        st.write("[✓] Simulator launched.")
