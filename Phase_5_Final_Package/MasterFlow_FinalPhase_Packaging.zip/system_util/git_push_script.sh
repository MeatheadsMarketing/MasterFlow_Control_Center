#!/bin/bash
echo "[+] Committing and pushing to GitHub..."
git add .
git commit -m "Deploying MasterFlow v1.0"
git push origin main
echo "[✓] Push Complete"
