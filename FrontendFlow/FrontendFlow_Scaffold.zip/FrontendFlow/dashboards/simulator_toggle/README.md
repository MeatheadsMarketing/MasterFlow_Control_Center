# Simulator Toggle

UI toggle for live vs preview mode.