# Assistant UIs

Dashboards tied to specific assistants (e.g., Vault, Log Viewer, etc.)